<?php
include 'connection.php';
$q=mysqli_query($con,"SELECT * FROM security WHERE user='".$_POST['username']."' and pass='".$_POST['password']."'");
if(mysqli_num_rows($q)>0){
	echo "1";
}
else{
	echo "0";
}
?>