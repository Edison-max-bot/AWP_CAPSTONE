<?php
$con=mysqli_connect("localhost","root","","inventory_db");
?>