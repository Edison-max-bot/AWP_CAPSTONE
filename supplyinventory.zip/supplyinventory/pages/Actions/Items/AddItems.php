<?php
include'../connection.php';


$c=mysqli_query($con,"SELECT * FROM category WHERE categoryDesc='".$_POST['selcat']."'");
$rowsC=mysqli_fetch_array($c);

$u=mysqli_query($con,"SELECT * from unit WHERE unitDesc='".$_POST['selunit']."'");
$rowsU=mysqli_fetch_array($u);

if($_POST['p_id']==""){
	mysqli_query($con,"INSERT into items(barcode,itemDesc,cid,uid,qty) values ('".$_POST['barcode']."','".$_POST['item']."','".$rowsC[0]."','".$rowsU[0]."','".$_POST['qty']."')");
	echo "1";
}
else{
	mysqli_query($con,"UPDATE items set barcode='".$_POST['barcode']."', itemDesc='".$_POST['item']."', cid='".$rowsC[0]."', uid='".$rowsU[0]."', qty='".$_POST['qty']."' WHERE iid='".$_POST['p_id']."'");
	echo "2";
}
?>